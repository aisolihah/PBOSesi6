package com.macbook.mycompany;

public interface VolumeControl {
    void increaseVolume();
    void decreaseVolume();
}
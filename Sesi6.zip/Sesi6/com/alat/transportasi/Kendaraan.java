package com.alat.transportasi;
public abstract class Kendaraan{
    String merk;
    String jenis;//darat, udara, laut

    Kendaraan(String merk, String jenis){
        this.merk = merk;
        this.jenis = jenis;
    }
    public Kendaraan(){

    }

    abstract void setKendaraan(String merk, String jenis);
    abstract void setMerkJenis();

    public String toString(){
        return "Merk : " + merk + "\n" + "Jenis : " + jenis;
    }
}